from __future__ import absolute_import
from hybmeshpack import config as config
from six.moves import map

class HybMeshVersion:
    def __init__(self, s):
        """initializes version for string of "1.2.3" type"""
        try:
            def only_nums(n):
                return ''.join(k for k in n if k.isdigit())

            self.nums = list(map(only_nums, s.split('.')))
            self.nums = list(map(int, [n for n in self.nums if len(n) > 0]))
            if len(self.nums) != 3:
                raise
        except Exception:
            raise Exception("Invalid version string: %s" % str(s))

    def __str__(self):
        return '.'.join(map(str, self.nums))

    def __cmp__(self, other):
        if not isinstance(other, HybMeshVersion):
            raise Exception("Invalid comparison")
        return cmp(self.nums, other.nums)

    @staticmethod
    def last():
        import six.moves.urllib.request, six.moves.urllib.error, six.moves.urllib.parse
        import json
        try:
            response = six.moves.urllib.request.urlopen(config.last_ver_url, timeout=1)
            r = json.loads(response.read())
            return HybMeshVersion(r['tag_name'])
        except:
            return None

    @staticmethod
    def current():
        '-> HybMeshVersion'
        return HybMeshVersion(config.version)


def check_for_updates():
    '->(str, str, -1/0/1): current version, latest version, cur<lat / == / >'
    cv = HybMeshVersion.current()
    lv = HybMeshVersion.last()
    if lv is not None:
        cmpres = cmp(cv, lv)
        lvs = str(lv)
    else:
        cmpres = None
        lvs = None
    return (str(cv), lvs, cmpres)


def project_url():
    '-> github url of the hybmesh project'
    return config.proj_url


def get_lib_fn(string_id):
    """ string_id:
            cport
    """
    import glob
    if string_id == 'cport':
        c = glob.glob("%s/*hmcport*" % config.libdir)
        if len(c) == 0:
            raise Exception("libhmcport was not found at %s"
                            % config.libdir)
        return c[0]
    else:
        raise Exception("Unknown library %s" % string_id)

def get_lib_fn(string_id):
    """ string_id:
    cport
    """
    import glob
    import os

    if string_id == 'cport':
        possible_dirs = [
            "/usr/local/lib/hybmesh",
            "/usr/lib/hybmesh",
            config.libdir,
            "/usr/lib",
            "/usr/local/lib",
        ]
        ld_library_path = os.environ.get('LD_LIBRARY_PATH', '')
        ld_paths = ld_library_path.split(':') if ld_library_path else []
        possible_dirs.extend(ld_paths)

        for libdir in possible_dirs:
            pattern = os.path.join(libdir, "*hmcport*")
            c = glob.glob(pattern)
            if len(c) > 0:
                return c[0]
        raise Exception("libhmcport was not found. Checked directories: %s" % str(possible_dirs))
    else:
        raise Exception("Unknown library %s" % string_id)
